#!bin/sh
#train suffix tagger
#python perceptron.py > suffix_tagger.model

#test
python test.py
